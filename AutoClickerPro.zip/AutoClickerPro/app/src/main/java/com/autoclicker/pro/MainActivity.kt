package com.autoclicker.pro

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var statusTv: TextView
    private lateinit var statusDot: View
    private lateinit var enableBtn: TextView
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setBackgroundDrawable(
            GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#0F0C29"), Color.parseColor("#302B63"), Color.parseColor("#24243E"))
            )
        )
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.parseColor("#24243E")

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(44), dp(18), dp(28))
        }
        setContentView(ScrollView(this).apply { addView(col); isFillViewport = true })

        // ── шапка
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "▶"; setTextColor(WHITE); textSize = 24f; gravity = Gravity.CENTER
            background = grad(PURPLE, CYAN, 0f, true)
        }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { rightMargin = dp(14) })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(text("AutoClicker Pro", 26f, WHITE, true))
        titles.addView(text("Запоминает действия и повторяет сам", 13f, GRAY))
        head.addView(titles)
        col.addView(head, lp(bottom = 18))

        // ── статус службы
        val st = card(col, null)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        statusDot = View(this).apply { background = rounded(GRAY, dp(6).toFloat()) }
        row.addView(statusDot, LinearLayout.LayoutParams(dp(12), dp(12)).apply { rightMargin = dp(10) })
        statusTv = text("", 15f, WHITE, true)
        row.addView(statusTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        enableBtn = TextView(this).apply {
            text = "Включить"; setTextColor(WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(dp(16), dp(8), dp(16), dp(8))
            background = grad(PURPLE, CYAN, dp(18).toFloat())
            setOnClickListener { openAccessibility() }
        }
        row.addView(enableBtn)
        st.addView(row)

        // ── время работы
        val c1 = card(col, "ВРЕМЯ РАБОТЫ БОТА")
        c1.addView(chips("minutes", listOf("∞" to 0, "15м" to 15, "30м" to 30, "1ч" to 60, "3ч" to 180, "8ч" to 480), 0))
        // ── скорость
        val c2 = card(col, "СКОРОСТЬ ПОВТОРА")
        c2.addView(chips("speed", listOf("0.5×" to 5, "1×" to 10, "2×" to 20, "3×" to 30), 10))
        // ── пауза между циклами
        val c3 = card(col, "ПАУЗА МЕЖДУ ЦИКЛАМИ")
        c3.addView(chips("pause", listOf("0.3с" to 300, "1с" to 1000, "3с" to 3000, "10с" to 10000), 1000))

        // ── кнопка запуска
        col.addView(TextView(this).apply {
            text = "ЗАПУСТИТЬ ПАНЕЛЬ  ▶"; setTextColor(WHITE); textSize = 16f
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = grad(PURPLE, CYAN, dp(30).toFloat())
            elevation = dp(6).toFloat()
            setOnClickListener {
                val s = ClickerService.instance
                if (s == null) {
                    Toast.makeText(this@MainActivity, "Сначала включи службу AutoClicker Pro", Toast.LENGTH_LONG).show()
                    openAccessibility()
                } else {
                    s.showPanel()
                    moveTaskToBack(true)
                }
            }
        }, lp(h = 60, top = 4, bottom = 14))

        // ── инструкция
        val c4 = card(col, "КАК ПОЛЬЗОВАТЬСЯ")
        c4.addView(text(
            "1. Включи службу «AutoClicker Pro» в Специальных возможностях.\n\n" +
            "2. Нажми «Запустить панель» — появится мини-окно.\n\n" +
            "3. Открой нужное приложение, нажми ● и делай всё как обычно: тапы, свайпы, паузы запоминаются.\n\n" +
            "4. Нажми ✓ — запись сохранена. Нажми ▶ — бот повторяет всё по кругу, пока не кончится таймер.\n\n" +
            "5. Окно двигай за заголовок, размер меняй уголком ◢, сворачивай «–», закрывай ✕. " +
            "Экран во время работы не гаснет — поставь телефон на зарядку.", 13f, Color.parseColor("#C9C7E0")
        ))
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val on = ClickerService.instance != null
        (statusDot.background as GradientDrawable).setColor(if (on) GREEN else RED)
        statusTv.text = if (on) "Служба включена" else "Служба выключена"
        enableBtn.visibility = if (on) View.GONE else View.VISIBLE
    }

    private fun openAccessibility() {
        Toast.makeText(this, "Найди «AutoClicker Pro» и включи", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    // ── помощники UI
    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setLineSpacing(0f, 1.1f)
    }

    private fun lp(h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val height = if (h > 0) dp(h) else h
        return LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height).apply {
            topMargin = dp(top); bottomMargin = dp(bottom)
        }
    }

    private fun card(parent: LinearLayout, title: String?): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#1FFFFFFF"), dp(20).toFloat(), Color.parseColor("#22FFFFFF"), dp(1))
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        if (title != null) c.addView(text(title, 11f, GRAY, true), lp(bottom = 10))
        parent.addView(c, lp(bottom = 12))
        return c
    }

    private fun chips(key: String, opts: List<Pair<String, Int>>, def: Int): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = ArrayList<TextView>()
        fun paint() {
            val cur = prefs.getInt(key, def)
            views.forEachIndexed { i, tv ->
                val sel = opts[i].second == cur
                tv.background = if (sel) grad(PURPLE, CYAN, dp(16).toFloat()) else rounded(Color.parseColor("#26FFFFFF"), dp(16).toFloat())
                tv.setTextColor(if (sel) WHITE else GRAY)
            }
        }
        opts.forEach { (label, v) ->
            val tv = TextView(this).apply {
                text = label; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { prefs.edit().putInt(key, v).apply(); paint() }
            }
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
            views.add(tv)
        }
        paint()
        return row
    }
}
