AutoClicker Pro — как собрать APK
1. Установи Android Studio (Koala или новее).
2. File → Open → выбери папку AutoClickerPro, дождись Gradle Sync.
3. Build → Build Bundle(s)/APK(s) → Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk
Установи на телефон. Если Android 13+ не даёт включить службу:
Настройки → Приложения → AutoClicker Pro → ⋮ → «Разрешить ограниченные настройки»,
затем Специальные возможности → AutoClicker Pro → Включить.
