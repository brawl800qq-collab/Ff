package com.autoclicker.pro

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

val PURPLE = Color.parseColor("#7C4DFF")
val CYAN = Color.parseColor("#00E5FF")
val RED = Color.parseColor("#FF3B5C")
val RED2 = Color.parseColor("#FF7A59")
val GREEN = Color.parseColor("#2ECC71")
val GREEN2 = Color.parseColor("#00D2A0")
val GRAY = Color.parseColor("#8E8CA8")
val GRAY2 = Color.parseColor("#5B5978")
val WHITE = Color.WHITE

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun rounded(color: Int, radius: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (strokeW > 0) setStroke(strokeW, stroke)
    }

fun grad(c1: Int, c2: Int, radius: Float, oval: Boolean = false): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply {
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = radius
    }
