package com.autoclicker.pro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.hypot

class ClickerService : AccessibilityService() {

    companion object {
        @JvmStatic
        var instance: ClickerService? = null
    }

    private class Step(val delay: Long, val dur: Long, val pts: List<PointF>)

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val steps = ArrayList<Step>()

    // окна
    private var root: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var recView: FrameLayout? = null
    private var recLp: WindowManager.LayoutParams? = null

    // элементы панели
    private lateinit var dot: View
    private lateinit var titleTv: TextView
    private lateinit var minBtn: TextView
    private lateinit var body: LinearLayout
    private lateinit var timerTv: TextView
    private lateinit var infoTv: TextView
    private lateinit var btnRec: TextView
    private lateinit var btnPlay: TextView
    private lateinit var btnStop: TextView
    private lateinit var grip: TextView

    // состояние
    private var pw = 0
    private var ph = 0
    private var collapsed = false
    private var recording = false
    private var playing = false
    private var startAt = 0L
    private var loops = 0
    private var lastUp = 0L

    // временные для drag/resize
    private var dX = 0f; private var dY = 0f; private var dOx = 0; private var dOy = 0
    private var rW = 0; private var rH = 0

    // ───────────────────────── жизненный цикл ─────────────────────────
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        load()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        removePanel()
        instance = null
        return super.onUnbind(intent)
    }

    // ───────────────────────── настройки ─────────────────────────
    private fun minutes() = prefs.getInt("minutes", 0)
    private fun speed() = prefs.getInt("speed", 10) / 10f
    private fun pauseMs() = prefs.getInt("pause", 1000).toLong()

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ───────────────────────── панель ─────────────────────────
    fun showPanel() {
        if (root != null) return
        pw = dp(250); ph = dp(190)

        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#F0141230"), dp(24).toFloat(), PURPLE, dp(1))
            setPadding(dp(10), dp(8), dp(10), dp(6))
        }

        // шапка (за неё двигаем окно)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        dot = View(this).apply { background = rounded(GRAY, dp(5).toFloat()) }
        header.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(8) })
        titleTv = TextView(this).apply {
            text = "AutoClicker"; setTextColor(WHITE); textSize = 13f
            typeface = Typeface.DEFAULT_BOLD; maxLines = 1
        }
        header.addView(titleTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        minBtn = smallBtn("–") { toggleCollapse() }
        header.addView(minBtn, LinearLayout.LayoutParams(dp(30), dp(30)).apply { leftMargin = dp(4) })
        header.addView(smallBtn("✕") { removePanel() }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { leftMargin = dp(6) })

        header.setOnTouchListener { _, e ->
            val p = lp
            if (p != null) when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dX = e.rawX; dY = e.rawY; dOx = p.x; dOy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = dOx + (e.rawX - dX).toInt(); p.y = dOy + (e.rawY - dY).toInt()
                    wm.updateViewLayout(root, p)
                }
            }
            true
        }

        // тело
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        timerTv = TextView(this).apply {
            text = "00:00:00"; setTextColor(WHITE); typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)
        }
        infoTv = TextView(this).apply { setTextColor(GRAY); gravity = Gravity.CENTER; maxLines = 1 }
        val ctrl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        btnRec = circleBtn("●", RED, RED2) { toggleRecord() }
        btnPlay = circleBtn("▶", GREEN, GREEN2) { startPlay() }
        btnStop = circleBtn("■", GRAY2, GRAY) { stopAll() }
        ctrl.addView(btnRec); ctrl.addView(btnPlay); ctrl.addView(btnStop)
        body.addView(timerTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        body.addView(infoTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        body.addView(ctrl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })

        // уголок для изменения размера
        grip = TextView(this).apply { text = "◢"; setTextColor(PURPLE); textSize = 16f; setPadding(dp(14), 0, 0, 0) }
        grip.setOnTouchListener { _, e ->
            val p = lp
            if (p != null) when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dX = e.rawX; dY = e.rawY; rW = pw; rH = ph }
                MotionEvent.ACTION_MOVE -> {
                    val dm = resources.displayMetrics
                    pw = (rW + (e.rawX - dX)).toInt().coerceIn(dp(180), dm.widthPixels)
                    ph = (rH + (e.rawY - dY)).toInt().coerceIn(dp(140), dm.heightPixels)
                    p.width = pw; p.height = ph
                    wm.updateViewLayout(root, p)
                    applySize()
                }
            }
            true
        }

        r.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        r.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        r.addView(grip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.END })

        val p = WindowManager.LayoutParams(
            pw, ph, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(20); y = dp(120) }

        wm.addView(r, p)
        root = r; lp = p
        collapsed = false
        applySize()
        updateUi()
    }

    private fun removePanel() {
        if (root == null) return
        if (recording) stopRecord()
        if (playing) stopPlay()
        try { wm.removeView(root) } catch (e: Exception) {}
        root = null; lp = null
    }

    private fun smallBtn(t: String, click: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(WHITE); textSize = 14f; gravity = Gravity.CENTER
        background = rounded(Color.parseColor("#26FFFFFF"), dp(15).toFloat())
        setOnClickListener { click() }
    }

    private fun circleBtn(t: String, c1: Int, c2: Int, click: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(WHITE); gravity = Gravity.CENTER
        background = grad(c1, c2, 0f, true)
        elevation = dp(4).toFloat()
        setOnClickListener { click() }
    }

    private fun applySize() {
        val sc = minOf(pw / dp(250).toFloat(), ph / dp(190).toFloat()).coerceIn(0.6f, 2.2f)
        timerTv.setTextSize(TypedValue.COMPLEX_UNIT_PX, dp(34) * sc)
        infoTv.setTextSize(TypedValue.COMPLEX_UNIT_PX, dp(11) * sc)
        val b = (dp(50) * sc).toInt()
        val m = (dp(6) * sc).toInt()
        for (v in listOf(btnRec, btnPlay, btnStop)) {
            v.layoutParams = LinearLayout.LayoutParams(b, b).apply { setMargins(m, 0, m, 0) }
            v.setTextSize(TypedValue.COMPLEX_UNIT_PX, b * 0.42f)
        }
    }

    private fun toggleCollapse() {
        collapsed = !collapsed
        val vis = if (collapsed) View.GONE else View.VISIBLE
        body.visibility = vis; grip.visibility = vis
        minBtn.text = if (collapsed) "+" else "–"
        titleTv.minWidth = if (collapsed) dp(80) else 0
        val p = lp ?: return
        p.width = if (collapsed) WindowManager.LayoutParams.WRAP_CONTENT else pw
        p.height = if (collapsed) WindowManager.LayoutParams.WRAP_CONTENT else ph
        wm.updateViewLayout(root, p)
        refreshTimer()
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format("%02d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
    }

    private fun refreshTimer() {
        if (root == null) return
        val lim = minutes() * 60_000L
        val t = if (playing) {
            val el = SystemClock.elapsedRealtime() - startAt
            if (lim > 0) maxOf(0L, lim - el) else el
        } else lim
        val s = fmt(t)
        timerTv.text = s
        titleTv.text = if (collapsed) s else "AutoClicker"
    }

    private fun updateUi() {
        val r = root ?: return
        (dot.background as GradientDrawable).setColor(when { recording -> RED; playing -> GREEN; else -> GRAY })
        btnRec.text = if (recording) "✓" else "●"
        btnPlay.alpha = if (playing) 0.45f else 1f
        infoTv.text = when {
            recording -> "● Запись · шагов: ${steps.size}"
            playing -> "Цикл ${loops + 1} · шагов: ${steps.size}"
            steps.isEmpty() -> "Нажми ●, чтобы записать"
            else -> "Готов · шагов: ${steps.size}"
        }
        r.keepScreenOn = playing   // экран не гаснет, пока бот работает
        refreshTimer()
    }

    // ───────────────────────── запись ─────────────────────────
    private fun toggleRecord() { if (recording) stopRecord() else startRecord() }

    private fun startRecord() {
        if (playing) stopPlay()
        steps.clear(); lastUp = 0L; recording = true

        val v = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#14FF3B5C")); setStroke(dp(3), RED)
            }
        }
        v.addView(TextView(this).apply {
            text = "● ЗАПИСЬ  —  делай нажатия и свайпы"
            setTextColor(WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = rounded(Color.parseColor("#CCFF3B5C"), dp(20).toFloat())
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(60) })

        var pts = ArrayList<PointF>(); var t0 = 0L; var delay = 0L
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    pts = arrayListOf(PointF(e.rawX, e.rawY))
                    t0 = SystemClock.uptimeMillis()
                    delay = if (lastUp == 0L) 0L else (t0 - lastUp).coerceAtMost(600_000L)
                }
                MotionEvent.ACTION_MOVE -> {
                    val l = pts.last()
                    if (hypot(e.rawX - l.x, e.rawY - l.y) > dp(10)) pts.add(PointF(e.rawX, e.rawY))
                }
                MotionEvent.ACTION_UP -> {
                    val now = SystemClock.uptimeMillis()
                    val l = pts.last()
                    if (hypot(e.rawX - l.x, e.rawY - l.y) > dp(4)) pts.add(PointF(e.rawX, e.rawY))
                    val st = Step(delay, (now - t0).coerceIn(40L, 60_000L), simplify(pts))
                    steps.add(st); lastUp = now
                    updateUi()
                    h.post { forward(st) }   // чтобы приложение под окном тоже отреагировало
                }
            }
            true
        }

        val p = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(v, p)
        recView = v; recLp = p
        h.post { // панель поверх окна записи
            val r = root; val q = lp
            if (r != null && q != null) try { wm.removeView(r); wm.addView(r, q) } catch (e: Exception) {}
        }
        updateUi()
    }

    private fun stopRecord() {
        recording = false
        try { wm.removeView(recView) } catch (e: Exception) {}
        recView = null; recLp = null
        save()
        updateUi()
        toast("Записано шагов: ${steps.size}")
    }

    private fun simplify(src: List<PointF>): List<PointF> {
        if (src.size <= 40) return src
        val k = src.size / 40 + 1
        val out = ArrayList<PointF>()
        for (i in src.indices step k) out.add(src[i])
        if (out.last() !== src.last()) out.add(src.last())
        return out
    }

    private fun forward(s: Step) {
        val v = recView ?: return
        val p = recLp ?: return
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(v, p) } catch (e: Exception) { return }
        val restore = {
            val v2 = recView; val p2 = recLp
            if (recording && v2 != null && p2 != null) {
                p2.flags = p2.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                try { wm.updateViewLayout(v2, p2) } catch (e: Exception) {}
            }
        }
        val ok = dispatchGesture(gesture(s), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { restore() }
            override fun onCancelled(g: GestureDescription?) { restore() }
        }, null)
        if (!ok) restore()
    }

    // ───────────────────────── воспроизведение ─────────────────────────
    private fun gesture(s: Step): GestureDescription {
        val p = Path()
        p.moveTo(s.pts.first().x, s.pts.first().y)
        for (i in 1 until s.pts.size) p.lineTo(s.pts[i].x, s.pts[i].y)
        return GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, s.dur.coerceIn(1L, 60_000L)))
            .build()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!playing) return
            val lim = minutes() * 60_000L
            if (lim > 0 && SystemClock.elapsedRealtime() - startAt >= lim) {
                stopPlay(); toast("Время вышло — бот остановлен"); return
            }
            refreshTimer()
            h.postDelayed(this, 500)
        }
    }

    private fun startPlay() {
        if (playing) return
        if (recording) stopRecord()
        if (steps.isEmpty()) { toast("Сначала запиши действия ●"); return }
        playing = true; loops = 0; startAt = SystemClock.elapsedRealtime()
        updateUi()
        h.post(tick)
        runStep(0)
    }

    private fun runStep(i: Int) {
        if (!playing) return
        if (i >= steps.size) {
            loops++; updateUi()
            h.postDelayed({ runStep(0) }, pauseMs())
            return
        }
        val s = steps[i]
        h.postDelayed({
            if (!playing) return@postDelayed
            val ok = dispatchGesture(gesture(s), object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { runStep(i + 1) }
                override fun onCancelled(g: GestureDescription?) { runStep(i + 1) }
            }, null)
            if (!ok) h.postDelayed({ runStep(i + 1) }, 200)
        }, (s.delay / speed()).toLong())
    }

    private fun stopPlay() {
        playing = false
        h.removeCallbacksAndMessages(null)
        updateUi()
    }

    private fun stopAll() {
        if (recording) stopRecord()
        if (playing) stopPlay()
    }

    // ───────────────────────── хранение ─────────────────────────
    private fun save() {
        val arr = JSONArray()
        for (s in steps) {
            val pa = JSONArray()
            for (pt in s.pts) pa.put(JSONArray().put(pt.x.toDouble()).put(pt.y.toDouble()))
            arr.put(JSONObject().put("d", s.delay).put("t", s.dur).put("p", pa))
        }
        prefs.edit().putString("steps", arr.toString()).apply()
    }

    private fun load() {
        steps.clear()
        try {
            val arr = JSONArray(prefs.getString("steps", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val pa = o.getJSONArray("p")
                val l = ArrayList<PointF>()
                for (j in 0 until pa.length()) {
                    val q = pa.getJSONArray(j)
                    l.add(PointF(q.getDouble(0).toFloat(), q.getDouble(1).toFloat()))
                }
                if (l.isNotEmpty()) steps.add(Step(o.getLong("d"), o.getLong("t"), l))
            }
        } catch (e: Exception) { steps.clear() }
    }
}
